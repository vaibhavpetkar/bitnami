# This file is a part of Redmine Invoices (redmine_contacts_invoices) plugin,
# invoicing plugin for Redmine
#
# Copyright (C) 2011-2024 RedmineUP
# https://www.redmineup.com/
#
# redmine_contacts_invoices is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_contacts_invoices is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_contacts_invoices.  If not, see <http://www.gnu.org/licenses/>.

class AddInvoiceRecurringAttributes < ActiveRecord::Migration[4.2]
  def change
    add_column :invoices, :is_recurring, :boolean, :default => false
    add_column :invoices, :recurring_period, :string
    add_column :invoices, :recurring_occurrences, :integer
    add_column :invoices, :recurring_action, :integer
    add_column :invoices, :recurring_profile_id, :integer, :index => true
    add_column :invoices, :recurring_number, :integer
  end
end
