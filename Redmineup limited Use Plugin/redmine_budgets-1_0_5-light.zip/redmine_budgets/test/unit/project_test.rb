# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class ProjectTest < ActiveSupport::TestCase
  fixtures :projects, :roles, :members, :member_roles, :users,
           :trackers, :enumerations, :issue_statuses, :enabled_modules

  create_fixtures(redmine_budgets_fixtures_directory, [:issues, :time_entries, :user_rates, :billing_details])

  def setup
    Setting.plugin_redmine_budgets = {}
    @project = Project.find(1)
  end

  def test_should_allowed_to_edit_bill_rate_type
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
    assert @project.allowed_to_edit?(:bill_rate_type)
  end

  def test_should_not_allowed_to_edit_bill_rate_type
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE
    assert !@project.allowed_to_edit?(:bill_rate_type)
  end

  def test_should_not_allowed_to_edit_bill_rate
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE
    assert !@project.allowed_to_edit?(:bill_rate)
    set_billing_settings_for @project, billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
    assert !@project.allowed_to_edit?(:bill_rate)
  end

  def test_on_billing_type_not_billable_and_budget_type_no_budget
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 0,
      non_billable_hours: 93.5,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: nil,

      budget: nil,
      remaining_budget: 0,
      remaining_budget_progress: 0,

      money_budget: nil,
      spent_money: nil,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_not_billable_and_budget_type_project_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
      project_cost: 1000,
      budget_type: BillingDetail::BUDGET_TYPE_PROJECT_TIME,
      budget: 1000
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 0,
      non_billable_hours: 93.5,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: nil,

      budget: 1000,
      remaining_budget: 906.5,
      remaining_budget_progress: 90.65,

      money_budget: nil,
      spent_money: nil,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: 1000,
      spent_hours: 93.5,
      spent_hours_progress: 9.35,
      remaining_hours: 906.5,
      remaining_hours_progress: 90.65,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_not_billable_and_budget_type_issues_time
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_TIME
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 0,
      non_billable_hours: 93.5,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: nil,

      budget: nil,
      remaining_budget: 108,
      remaining_budget_progress: 53.59801488833747,

      money_budget: nil,
      spent_money: nil,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: 201.5,
      spent_hours: 93.5,
      spent_hours_progress: 46.40198511166253,
      remaining_hours: 108,
      remaining_hours_progress: 53.59801488833747,

      profit: nil,
      profit_progress: nil
    }
  end

  def test_on_billing_type_time_and_materials_and_budget_type_no_budget_and_bill_rate_type_by_user
    set_billing_settings_for @project, {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_USER,
      budget_type: BillingDetail::BUDGET_TYPE_NO_BUDGET
    }

    check_attributes_for @project, {
      total_spent_hours: 93.5,
      billable_hours: 93.5,
      non_billable_hours: 0,

      total_costs: 1368.75,
      costs: 1368.75,
      billable_amount: 2183.75,

      budget: nil,
      remaining_budget: 0,
      remaining_budget_progress: 0,

      money_budget: nil,
      spent_money: 2183.75,
      spent_money_progress: 100,
      remaining_money: 0,
      remaining_money_progress: 0,

      hours_budget: nil,
      spent_hours: 93.5,
      spent_hours_progress: 100,
      remaining_hours: 0,
      remaining_hours_progress: 0,

      profit: 815,
      profit_progress: 37.32112192329708
    }
  end
end
