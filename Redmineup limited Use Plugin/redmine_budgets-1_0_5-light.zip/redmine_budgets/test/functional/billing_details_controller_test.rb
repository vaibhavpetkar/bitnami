# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class BillingDetailsControllerTest < ActionController::TestCase
  include Redmine::I18n

  fixtures :projects, :roles, :members, :member_roles, :users, :issues,
           :trackers, :enumerations, :issue_statuses, :enabled_modules

  create_fixtures(redmine_budgets_fixtures_directory, [:time_entries, :user_rates, :billing_details])

  def setup
    @admin = User.find(1)
    @user = User.find(2)

    @project_1 = Project.find(1)
    @project_2 = Project.find(2)

    @issue_1 = Issue.find(1)
    @issue_2 = Issue.find(2)

    @project_billing_settings = {
      billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS,
      bill_rate_type: BillingDetail::BILL_RATE_BY_ISSUE,
      budget_type: BillingDetail::BUDGET_TYPE_ISSUES_FEE
    }

    @issue_billing_settings = { billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE }

    EnabledModule.create(project: @project_1, name: 'budgets')
    EnabledModule.create(project: @project_2, name: 'budgets')
    Setting.plugin_redmine_budgets = {}
  end

  # ===== Action: update_project_billing_detail =====

  def test_should_create_project_billing_details
    @request.session[:user_id] = @admin.id
    assert_difference 'BillingDetail.count' do
      post_update_project_billing_detail(@project_2)
      assert_response :success
      assert_equal flash[:notice], l(:notice_successful_update)
    end
  end

  def test_should_update_project_billing_details
    @request.session[:user_id] = @admin.id
    should_update_project_billing_detail
  end

  def test_should_update_project_billing_detail_for_regular_user
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_project_billing_details
    should_update_project_billing_detail
  end

  def test_should_not_update_project_billing_detail_for_regular_user
    @request.session[:user_id] = @user.id
    post_update_project_billing_detail(@project_1)
    assert_response :forbidden
  end

  def test_should_not_update_project_billing_detail_for_anonymous
    post_update_project_billing_detail(@project_1)
    assert_response :redirect
  end

  # ===== Action: edit_issue_billing_detail =====

  def test_should_get_edit_issue_billing_detail_for_admin
    @request.session[:user_id] = @admin.id
    compatible_xhr_request :get, :edit_issue_billing_detail, issue_id: @issue_1.id
    assert_response :success
  end

  def test_should_get_edit_issue_billing_detail_for_regular_user
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_issue_billing_details
    compatible_xhr_request :get, :edit_issue_billing_detail, issue_id: @issue_1.id
    assert_response :success
  end

  def test_should_not_get_edit_issue_billing_detail_for_regular_user
    @request.session[:user_id] = @user.id
    compatible_xhr_request :get, :edit_issue_billing_detail, issue_id: @issue_1.id
    assert_response :forbidden
  end

  def test_should_not_get_edit_issue_billing_detail_for_anonymous
    compatible_xhr_request :get, :edit_issue_billing_detail, issue_id: @issue_1.id
    assert_response :unauthorized
  end

  # ===== Action: update_issue_billing_detail =====

  def test_should_create_issue_billing_details
    @request.session[:user_id] = @admin.id
    @project_1.billing_detail.billing_type = BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
    @project_1.billing_detail.bill_rate_type = BillingDetail::BILL_RATE_BY_ISSUE
    @project_1.billing_detail.save

    assert_difference 'BillingDetail.count' do
      post_update_issue_billing_detail @issue_2, bill_rate: 50
      assert_equal 50, @issue_2.billing_detail.reload.bill_rate
      assert_response :success
    end
  end

  def test_should_update_issue_billing_details
    @request.session[:user_id] = @admin.id
    should_update_issue_billing_detail
  end

  def test_should_change_issue_billing_type
    @request.session[:user_id] = @admin.id
    @project_1.billing_detail.billing_type = BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
    @project_1.billing_detail.save

    assert_equal @issue_1.billing_detail.billing_type, BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
    post_update_issue_billing_detail @issue_1, billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE
    assert_equal BillingDetail::BILLING_TYPE_NOT_BILLABLE, @issue_1.billing_detail.reload.billing_type
    assert_response :success
  end

  def test_should_change_issue_bill_rate
    @request.session[:user_id] = @admin.id
    @project_1.billing_detail.billing_type = BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
    @project_1.billing_detail.bill_rate_type = BillingDetail::BILL_RATE_BY_ISSUE
    @project_1.billing_detail.save

    assert_nil @issue_1.billing_detail.bill_rate
    post_update_issue_billing_detail @issue_1, bill_rate: 50
    assert_equal 50, @issue_1.billing_detail.reload.bill_rate
    assert_response :success
  end

  def test_should_change_issue_budget
    @request.session[:user_id] = @admin.id
    @project_1.billing_detail.billing_type = BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
    @project_1.billing_detail.budget_type = BillingDetail::BUDGET_TYPE_ISSUES_FEE
    @project_1.billing_detail.save

    assert_nil @issue_1.billing_detail.budget
    post_update_issue_billing_detail @issue_1, budget: 1000
    assert_equal 1000, @issue_1.billing_detail.reload.budget
    assert_response :success
  end
  
  def test_should_not_change_issue_billing_type
    @request.session[:user_id] = @admin.id
    billing_type = @issue_1.billing_detail.billing_type
    post_update_issue_billing_detail @issue_1, billing_type: BillingDetail::BILLING_TYPE_NOT_BILLABLE
    assert_response :success
    assert_equal billing_type, @issue_1.billing_detail.reload.billing_type
  end

  def test_should_not_change_issue_bill_rate
    @request.session[:user_id] = @admin.id
    bill_rate = @issue_1.billing_detail.bill_rate
    post_update_issue_billing_detail @issue_1, bill_rate: 50
    assert_response :success
    assert bill_rate == @issue_1.billing_detail.reload.bill_rate
  end

  def test_should_not_change_issue_budget
    @request.session[:user_id] = @admin.id
    budget = @issue_1.billing_detail.budget
    post_update_issue_billing_detail @issue_1, budget: 50
    assert_response :success
    assert budget == @issue_1.billing_detail.reload.budget
  end

  def test_should_update_issue_billing_detail_for_regular_user
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_issue_billing_details
    should_update_issue_billing_detail
  end

  def test_should_not_update_issue_billing_detail_for_regular_user
    @request.session[:user_id] = @user.id
    post_update_issue_billing_detail @issue_1
    assert_response :forbidden
  end

  def test_should_not_update_issue_billing_detail_for_anonymous
    post_update_issue_billing_detail @issue_1
    assert_response :unauthorized
  end

  private

  def post_update_project_billing_detail(project, billing_settings = @project_billing_settings)
    compatible_request :post, :update_project_billing_detail,
                       project_id: project.id, billing_settings: billing_settings
  end

  def post_update_issue_billing_detail(issue, billing_settings = @issue_billing_settings)
    compatible_xhr_request :post, :update_issue_billing_detail,
                       issue_id: issue.id, billing_settings: billing_settings
  end

  def should_update_project_billing_detail
    assert_no_difference 'BillingDetail.count' do
      [:billing_type, :bill_rate_type, :budget_type].each do |attr|
        assert_not_equal @project_1.billing_detail.send(attr), @project_billing_settings[attr]
      end

      post_update_project_billing_detail(@project_1, @project_billing_settings)
      assert_response :success
      assert_equal flash[:notice], l(:notice_successful_update)

      @project_1.billing_detail.reload
      [:billing_type, :bill_rate_type, :budget_type].each do |attr|
        assert_equal @project_1.billing_detail.send(attr), @project_billing_settings[attr]
      end
    end
  end

  def should_update_issue_billing_detail
    @project_1.billing_detail.billing_type = BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS
    @project_1.billing_detail.save

    assert_no_difference 'BillingDetail.count' do
      assert_not_equal @issue_1.billing_detail.billing_type, @issue_billing_settings[:billing_type]
      post_update_issue_billing_detail @issue_1
      assert_equal @issue_1.billing_detail.reload.billing_type, @issue_billing_settings[:billing_type]
      assert_response :success
    end
  end
end
