# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class ProjectsControllerTest < ActionController::TestCase
  fixtures :projects, :roles, :members, :member_roles, :users, :issues,
           :trackers, :enumerations, :issue_statuses, :enabled_modules

  create_fixtures(redmine_budgets_fixtures_directory, [:time_entries, :user_rates, :billing_details])

  def setup
    @admin = User.find(1)
    @user = User.find(2)
    @project = Project.find(1)
    EnabledModule.create(project: @project, name: 'budgets')
    Setting.plugin_redmine_budgets = {}
  end

  def test_should_get_settings
    @request.session[:user_id] = @admin.id
    compatible_request :get, :settings, id: @project.id
    assert_response :success
    assert_select '#tab-billing-details', 1
    assert_select '#tab-content-billing-details', 1
  end

  def test_should_get_settings_for_regular_user
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :manage_project_billing_details
    compatible_request :get, :settings, id: @project.id
    assert_response :success
    assert_select '#tab-billing-details', 1
    assert_select '#tab-content-billing-details', 1
  end

  def test_should_get_settings_without_billing_settings
    @request.session[:user_id] = @user.id
    compatible_request :get, :settings, id: @project.id
    assert_response :success
    assert_select '#tab-billing-details', 0
    assert_select '#tab-content-billing-details', 0
  end

  def test_should_get_show_with_billing_info
    @request.session[:user_id] = @admin.id
    compatible_request :get, :show, id: @project.id
    assert_response :success
    assert_select '.billing-budget.box', 1
  end

  def test_should_get_show_with_billing_info_for_regular_user
    @request.session[:user_id] = @user.id
    Role.find(1).add_permission! :view_project_billing_details
    compatible_request :get, :show, id: @project.id
    assert_response :success
    assert_select '.billing-budget.box', 1
  end

  def test_should_get_show_without_billing
    @request.session[:user_id] = @user.id
    compatible_request :get, :show, id: @project.id
    assert_response :success
    assert_select '.billing-budget.box', 0
  end
end
