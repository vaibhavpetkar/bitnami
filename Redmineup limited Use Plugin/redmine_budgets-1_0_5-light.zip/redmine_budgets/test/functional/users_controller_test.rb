# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class UsersControllerTest < ActionController::TestCase
  fixtures :users, :email_addresses
  create_fixtures(redmine_budgets_fixtures_directory, [:time_entries, :user_rates])

  def setup
    @admin = User.find(1)
    @user_2 = User.find(2)
    @user_4 = User.find(4)
    Setting.plugin_redmine_budgets = {}
  end

  def test_should_access_to_rates_tab_for_admin
    @request.session[:user_id] = @admin.id
    compatible_request :get, :edit, id: @user_2.id, tab: 'rates'
    assert_response :success
    assert_select "#tab-rates", 1
    assert_select "#tab-content-rates", 1
  end

  def test_should_show_rates_history_for_admin
    @request.session[:user_id] = @admin.id
    compatible_request :get, :show, id: @user_4.id
    assert_response :success
    assert_select ".user-rates", 1
  end

  def test_should_not_show_rates_history_without_permissions
    @request.session[:user_id] = @user_4.id
    assert @user_4.rates.present?
    compatible_request :get, :show, id: @user_4.id
    assert_response :success
    assert_select ".user-rates", 0
  end

  def test_should_show_rates_history_with_permission_view_rates
    @request.session[:user_id] = @user_2.id
    PeopleAcl.create(@user_2.id, ['view_people']) if RedmineBudgets.people_plugin_installed?
    @user_2.pref.rates_permission = RedmineBudgets::VIEW_RATES_PERMISSION
    @user_2.pref.save
    compatible_request :get, :show, id: @user_4.id
    assert_response :success
    assert_select ".user-rates", 1
  end

  def test_should_show_rates_history_with_permission_view_own_rates
    @request.session[:user_id] = @user_4.id
    @user_4.pref.rates_permission = RedmineBudgets::VIEW_OWN_RATES_PERMISSION
    @user_4.pref.save
    compatible_request :get, :show, id: @user_4.id
    assert_response :success
    assert_select ".user-rates", 1
  end

  def test_should_update_rates_permission
    @request.session[:user_id] = @admin.id
    assert_nil @user_2.pref.rates_permission
    compatible_request :post, :update, id: @user_2.id, user: { firstname: 'Changed' },
                       pref: { rates_permission: RedmineBudgets::EDIT_RATES_PERMISSION }

    assert_equal RedmineBudgets::EDIT_RATES_PERMISSION, @user_2.reload.pref.rates_permission
  end

  def test_should_not_update_rates_permission
    @request.session[:user_id] = @admin.id
    assert_nil @user_2.pref.rates_permission
    compatible_request :post, :update, id: @user_2.id, user: { firstname: 'Changed' },
                       pref: { rates_permission: 'incorrect value' }

    assert_nil @user_2.reload.pref.rates_permission
  end
end
