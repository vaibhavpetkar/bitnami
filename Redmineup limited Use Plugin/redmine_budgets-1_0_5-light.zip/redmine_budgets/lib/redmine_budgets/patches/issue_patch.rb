# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

module RedmineBudgets
  module Patches
    module IssuePatch
      def self.included(base)
        base.class_eval do
          
          include RedmineBudgets::Utils::UserRatesCalculation
          include InstanceMethods

          has_one :billing_detail, as: :billable, dependent: :destroy

          scope :by_project, ->(project) { where(project_id: project.is_a?(Project) ? project.id : project) }
          scope :live_search, ->(word) { where("(#{Issue.table_name}.subject LIKE ?)", "%#{word}%") }

          delegate *BillingSettingsAttributes::ISSUE_SETTINGS_ATTRIBUTES, to: :billing_settings
        end
      end

      module InstanceMethods
        def default_billing_settings
          settings = { billing_type: BillingDetail::BILLING_TYPE_TIME_AND_MATERIALS }

          BillingDetail.new(
            billable: self,
            settings: settings
          )
        end

        def billing_settings
          @billing_settings ||= billing_detail || default_billing_settings
        end

        def billable?
          project.billable? && !billing_type_not_billable?
        end

        def non_billable?
          !billable?
        end

        def billing_type_not_billable?
          allowed_to_edit?(:billing_type) &&
            billing_type == BillingDetail::BILLING_TYPE_NOT_BILLABLE
        end

        def allowed_to_edit?(attribute)
          case attribute.to_sym
          when :billing_type
            project.billing_type_time_and_materials?
          when :bill_rate
            project.allowed_to_edit?(:bill_rate_type) && project.bill_rate_by_issue?
          when :budget
            project.issues_fee_budget?
          end
        end

        def allowed_attribute?(attribute)
          allowed_to_edit?(attribute)
        end

        def allowed_to_edit_billing_detail?
          BillingSettingsAttributes::ISSUE_SETTINGS_ATTRIBUTES.any? { |attribute| allowed_to_edit?(attribute) }
        end

        def costs
          @costs ||= issue_costs(self)
        end

        def billable_amount
          @billable_amount ||=
            if project.billing_type_time_and_materials?
              spent_money
            end
        end

        def money_budget
          @money_budget ||= budget if project.issues_fee_budget?
        end

        def hours_budget
          @hours_budget ||= estimated_hours if project.issues_time_budget?
        end

        def spent_money
          @spent_money ||=
          if project.allowed_to_edit?(:bill_rate_type)
            calculate_spent_money
          end
        end

        def calculate_spent_money
          issue_billable_amount(self)
        end

        def spent_money_progress
          @spent_money_progress ||=
            if money_budget && spent_money
              money_budget == 0 ? 100 : spent_money * 100 / money_budget
            end
        end

        def spent_time
          @spent_time ||= time_entries.loaded? ? time_entries.to_a.sum(&:hours) : spent_hours
        end

        def spent_hours_progress
          @spent_hours_progress ||=
            if hours_budget
              hours_budget == 0 ? 100 : spent_time * 100 / hours_budget
            end
        end

        def remaining_money
          @remaining_money ||= money_budget - spent_money if money_budget && spent_money
        end

        def remaining_hours
          @remaining_hours ||= hours_budget - spent_time if hours_budget
        end

        def profit
          @profit ||= billable_amount - costs if billable_amount
        end

        def profit_progress
          @profit_progress ||=
            if profit
              billable_amount == 0 ? -100 : profit * 100 / billable_amount
            end
        end
      end
    end
  end
end

unless Issue.included_modules.include?(RedmineBudgets::Patches::IssuePatch)
  Issue.send(:include, RedmineBudgets::Patches::IssuePatch)
end
