# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2024 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

module RedmineBudgets
  module Patches
    module UserPatch
      def self.included(base)
        base.class_eval do
          include InstanceMethods

          has_many :time_entries
          has_many :rates, class_name: 'UserRate', foreign_key: :user_id, dependent: :destroy
        end
      end

      module InstanceMethods
        def allowed_to_view_user_rates?(user)
          admin? || has_permission_to_view_user_rates?(user)
        end

        def allowed_to_edit_user_rates?(user)
          admin? || has_permission_to_edit_user_rates?(user)
        end

        def has_permission_to_view_user_rates?(user)
          has_permission_to_edit_user_rates?(user) ||
            pref.rates_permission == RedmineBudgets::VIEW_RATES_PERMISSION ||
            (id == user.id && pref.rates_permission == RedmineBudgets::VIEW_OWN_RATES_PERMISSION)
        end

        def has_permission_to_edit_user_rates?(_user)
          pref.rates_permission == RedmineBudgets::EDIT_RATES_PERMISSION
        end
      end
    end
  end
end

unless User.included_modules.include?(RedmineBudgets::Patches::UserPatch)
  User.send(:include, RedmineBudgets::Patches::UserPatch)
end
